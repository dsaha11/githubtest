package MU007_USREGION_Pricing_v1.ContractPrice.sourceSAP;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2008-08-05 09:28:08 EDT
// -----( ON-HOST: hcsecpd1.rar.ncsus.na.jnj.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.text.*;
import java.util.*;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void calculateTimeDifferenceInMilliseconds (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(calculateTimeDifferenceInMilliseconds)>> ---
		// @sigtype java 3.5
		// [i] field:0:required startDateTime
		// [i] field:0:required endDateTime
		// [i] field:0:required startDateFormat
		// [i] field:0:required endDateFormat
		// [o] field:0:required dateDifferenceSec
		// [o] field:0:required dateDifferenceMin
		// [o] field:0:required dateDifferenceMillSec
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		pipelineCursor.first( "startDateTime" );
		String	startDateTime = (String) pipelineCursor.getValue();
		pipelineCursor.first( "endDateTime" );
		String	endDateTime = (String) pipelineCursor.getValue();
		pipelineCursor.first( "startDateFormat" );
		String	startDateFormat = (String) pipelineCursor.getValue();
		pipelineCursor.first( "endDateFormat" );
		String	endDateFormat = (String) pipelineCursor.getValue();
		
		
		
		if (startDateTime == null || endDateTime == null)
		{
				pipelineCursor.destroy();
				IDataCursor pipelineCursor_1 = pipeline.getCursor();
				pipelineCursor_1.last();
			
				pipelineCursor_1.insertAfter( "dateDifferenceMillSec","0");
				pipelineCursor_1.insertAfter( "dateDifferenceSec", "0");
				pipelineCursor_1.insertAfter( "dateDifferenceMin", "0");
			
				pipelineCursor_1.destroy();
				
			
		}
		
		else
		
		{
			//Check if we get . milliseconds format
		
			int index1 = startDateTime.indexOf('.');
			int index2 = endDateTime.indexOf('.');
			
			if (index1 < 0 || index2 < 0)
			{
				
				try
				{	pipelineCursor.destroy();
					String displayTimeMilliSec1 = "0";
					SimpleDateFormat sdf1 = new SimpleDateFormat(startDateFormat);
					Date sdt1 = sdf1.parse(startDateTime);
					SimpleDateFormat edf1 = new SimpleDateFormat(endDateFormat);
					Date edt1 = edf1.parse(endDateTime);
					long  timediff1 = edt1.getTime() - sdt1.getTime();
				
					IDataCursor pipelineCursor_1 = pipeline.getCursor();
					pipelineCursor_1.last();
			
					pipelineCursor_1.insertAfter( "dateDifferenceMillSec",Long.toString(timediff1));
					pipelineCursor_1.insertAfter( "dateDifferenceMin", Long.toString(timediff1/60000));
					pipelineCursor_1.insertAfter( "dateDifferenceSec", Long.toString(timediff1/1000));
			
					pipelineCursor_1.destroy();
				}
		
				catch (Exception e) 
				{
					
					IDataCursor pipelineCursor_1 = pipeline.getCursor();
					pipelineCursor_1.last();
			
					pipelineCursor_1.insertAfter( "dateDifferenceMillSec","0");
					pipelineCursor_1.insertAfter( "dateDifferenceSec", "0");
					pipelineCursor_1.insertAfter( "dateDifferenceMin", "0");
				
					pipelineCursor_1.destroy();
				}
		
			}
		
			else
		
			{	
				try 
				{
			
					String[] str = endDateTime.split("\\.");
					String endTimeInMicroSec ="0";
					String startTimeInMicroSec ="0";
					int millisecormicrosec = 0;
		
					if (str[1] != null)
					{
						//millisecormicrosec = str[1].length();
						endTimeInMicroSec = str[1].substring(0,3);
			
		
					}
		
					str = startDateTime.split("\\.");
					if (str[1] != null)
					{
					 	//millisecormicrosec = str[1].length();
						startTimeInMicroSec = str[1].substring(0,3);
			
		
					}
		
		
		
		
					
					if (pipelineCursor.first("startDateFormat"))
					{
						startDateFormat = (String) pipelineCursor.getValue();
					}
					else
					{
						startDateFormat = "yyyy-MM-dd";
					}
					
					if (pipelineCursor.first("endDateFormat"))
					{
						endDateFormat = (String) pipelineCursor.getValue();
					}
					else
					{
						endDateFormat = "yyyy-MM-dd";
					}
		
					pipelineCursor.destroy();
		
					
			
		
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					Date sdt = sdf.parse(startDateTime);
					SimpleDateFormat edf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					Date edt = edf.parse(endDateTime);
					long  timediff = edt.getTime() - sdt.getTime();
				
					//then subtract the millisecond level
					long timediffinMicrosec= Long.parseLong(endTimeInMicroSec.trim()) 
						- Long.parseLong(startTimeInMicroSec.trim()) ;
		
				
		
		
		
					String displayTimeSec = "0";
					String displayTimeMilliSec = "0";
					String displayTimeMin = "0";
					displayTimeSec = Long.toString(timediff/1000000);
					displayTimeMilliSec = Long.toString(timediff +timediffinMicrosec);
			
					displayTimeMin = Long.toString(timediff/60000000);
				
				
					// pipeline
					IDataCursor pipelineCursor_1 = pipeline.getCursor();
					pipelineCursor_1.last();
			
					pipelineCursor_1.insertAfter( "dateDifferenceMillSec",displayTimeMilliSec);
					pipelineCursor_1.insertAfter( "dateDifferenceSec", displayTimeSec);
					pipelineCursor_1.insertAfter( "dateDifferenceMin", displayTimeMin);
			
					pipelineCursor_1.destroy();
					
				}
				
				//Catch All kinds of exception
		 
				catch (Exception e) 
				{
					
					IDataCursor pipelineCursor_1 = pipeline.getCursor();
					pipelineCursor_1.last();
			
					pipelineCursor_1.insertAfter( "dateDifferenceMillSec","0");
					pipelineCursor_1.insertAfter( "dateDifferenceSec", "0");
					pipelineCursor_1.insertAfter( "dateDifferenceMin", "0");
				
					pipelineCursor_1.destroy();
				}
			}
		}
		// --- <<IS-END>> ---

                
	}
}

